#include "types.h"
#include "stat.h"
#include "user.h"
#include "uthread.h"

int fib(int x) {
//     printf(1, "inside fib\n");

    if (x == 0)
        return 0;

    if (x == 1)
        return 1;
    
    return fib(x-1)+fib(x-2);
}
void handler(int num){
    printf(1, "I'm blue dabadi dabada dabadi dabadaaaaaa %d\n",num);
}

void alarm_a(int num){
    printf(1,"Alarm!!!\n");
}

void start_function(void* a){
        printf(1, "hi! i'm thread number %d inside my function, my args: %d\n", uthred_self(), (int*)a);
        if(uthred_self() <10){
            uthred_join(5);
        }
        if(uthred_self()<10){
        
            uthred_sleep(10);
        }
        sleep(10);

        printf(1, "hi! i'm thread number %d in the end of my function\n", uthred_self());
        sleep(10);
}

int main() {

    //sighandler_t old = (sighandler_t)signal(1, handler);
    //printf(1, "old: %d\n", old);
    //sighandler_t new = (sighandler_t)
    
    uthread_init();
    for(int i=0; i<30; i++){
        int a = uthread_create(start_function,(int* )(i*10));
        printf(1, "result: %d\n", a);
    }
    
    //signal(1, handler);
//     signal(14, alarm_a);
    //printf(1, "new: %d\n", new);
    //int result = 
//     sigsend(getpid(), 14);
//     alarm(5);

//     fib(41);
    
    printf(1, "helooooooooooooooooooooooooooooooooooooo\n");
    //sleep(10)
    //printf(1, "result: %d\n", result);
    uthread_exit();
    
}
