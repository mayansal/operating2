#include "uthread.h"
#include "types.h"
#include "stat.h"
#include "user.h"
#include "x86.h"

#define STACK_SIZE  4096
#define MAX_UTHREADS 64
#define UTHREAD_QUANTA 5
#define SIGALRM 14

//__asm__("movl %%ebp, %0" : "=r"(var));            -       save ebp
//__asm__("movl %0, %%ebp " : : "r"(var));          -       load ebp

//     int threadID;
//     uthreadState state; 
//     struct trapframe *tf;
//     char* stack;
//     int sleepON;
//     int firstRun;
//     int wakeup_time;


//GLOBAL VARIABLE FOR MANTAINING USER LEVEL THREADS STROCTUR
uthread utTable[MAX_UTHREADS];
uthread* currentRunningThread;
int exit_process;

int uthread_init() {
    // Initializes the process’ threads table
    int i;
    for (i=0 ; i < MAX_UTHREADS ; i++) {
        utTable[i].threadID = i;
        utTable[i].state = UNUSED;
    }
    exit_process = 0;
    
    // Creates the main thread
    utTable[0].state = RUNNING;
    utTable[0].stack = (char *) malloc(sizeof (*(utTable[0].tf)));
    uint sp = (uint)utTable[0].stack + sizeof (*(utTable[0].tf));
    sp -= sizeof (*(utTable[0].tf));
    utTable[0].tf = (struct trapframe*)sp;
    utTable[0].sleepON = -1;
    utTable[0].firstRun = 0;
    utTable[0].wakeup_time = -1;
    currentRunningThread = &utTable[0];

    // Registers the SIGALRM handler to the uthread_schedule function
    signal(SIGALRM,uthread_schedule);
    // sigsend(getpid(), SIGALRM);
    
    // Executes the alarm system call with parameter UTHREAD_QUANTA=5
    alarm(UTHREAD_QUANTA);

    return 0;
}

int uthread_create(void (*start_func)(void *),void* arg)
{
    int i, sp;
    int ans = -1;
    for (i=0 ; i < MAX_UTHREADS ; i++) 
    {
        if (utTable[i].state == UNUSED)
        {
            //alocate & init stack, init tf
            utTable[i].stack = (char *) malloc(STACK_SIZE);
            sp = (int)utTable[i].stack + STACK_SIZE;
            sp -= sizeof (*(utTable[i].tf));
            utTable[i].tf = (struct trapframe*)sp;
            sp-=4;
            *(int *)sp = (int)arg;
            sp-=4;
            *(int *)sp = (int)uthread_exit;
            utTable[i].tf->eip = (uint)(void*)start_func;
            utTable[i].tf->ebp = sp;
            utTable[i].tf->esp = sp;
                         
            utTable[0].sleepON = -1;
            utTable[i].firstRun = 1;
            utTable[0].wakeup_time = -1;            
            utTable[i].state = RUNNABLE;
            ans = utTable[i].threadID;
            break;
        }
    }
    return ans;
}

void uthread_schedule(){  
    alarm(0);
    
    int i, ebp, tf_address;
    int temp_eip, temp_esp, temp_ebp;
    uthread* previousRunningThread = currentRunningThread;
    
//     // Update SLEEPING-time threads if necassary
//     for(int j = 0; j < MAX_UTHREADS; j++){
//         if(utTable[j].state == SLEEPING && utTable[j].wakeup_time >= uptime()){
//             utTable[j].state = RUNNABLE;
//             utTable[j].wakeup_time = -1;
//         }
//     }

    // Round Robin
    for (i = currentRunningThread->threadID+1; i < MAX_UTHREADS ; i++){
        if (utTable[i].state == RUNNABLE){
            currentRunningThread = &utTable[i];
            break;
        }
    }
    if(i == MAX_UTHREADS){
        for (i=0; i < currentRunningThread->threadID ; i++){
            if (utTable[i].state == RUNNABLE){
                currentRunningThread = &utTable[i];
                break;
            }
        }
    }
    // there is no runnable thread beside the running one
    if(i == previousRunningThread->threadID){
        // From exit    
        if(previousRunningThread->state==UNUSED){
            free(previousRunningThread->stack);
        }
        if(exit_process == 1){
            exit();
        }
        return;
    }

    printf(1,"transform from %d to %d\n", previousRunningThread->threadID, currentRunningThread->threadID);

    
    __asm__("movl %%ebp, %0" : "=r"(ebp));
    tf_address = ebp + 12;
    
    // Preservation - from process tf to previous tf
    memmove((*previousRunningThread).tf, ((struct trapframe*)tf_address), sizeof (struct trapframe));
    
    if(previousRunningThread->state == RUNNING){
        previousRunningThread->state = RUNNABLE;
    }
    // From exit    
    if(previousRunningThread->state==UNUSED){
        free(previousRunningThread->stack);
    }
    if(exit_process == 1){
        printf(1, "second\n");
        exit();
    }
    
    // Restoration - from current tf to process tf
    if(currentRunningThread->firstRun == 1){
        currentRunningThread->firstRun = 0;
        temp_eip = currentRunningThread->tf->eip;
        temp_esp = currentRunningThread->tf->esp;
        temp_ebp = currentRunningThread->tf->ebp;
        memmove((*currentRunningThread).tf, ((struct trapframe*)tf_address), sizeof (struct trapframe));
        (*currentRunningThread).tf->eip = temp_eip;
        (*currentRunningThread).tf->esp = temp_esp;
        (*currentRunningThread).tf->ebp = temp_ebp;
    }
    memmove((struct trapframe*) tf_address, (*currentRunningThread).tf, sizeof(struct trapframe));
    currentRunningThread->state = RUNNING;

    alarm(5);
        
    return;
}


void uthread_exit(){

    alarm(0);
    int i;
    uthread* terminatedRunningThread = currentRunningThread;

    printf(1, "i'm thread %d and i'm in exit wohooooooooooooo!\n", uthred_self());    
    
    // check if there are not-UNUSED threads (if there are not, we can exit)
    for(i=0; i< MAX_UTHREADS; i++){
        if(utTable[i].state != UNUSED && i!=terminatedRunningThread->threadID){
            break;
        }
    }
    if(i==MAX_UTHREADS){
        exit_process = 1;
    }
     
    // Close the terminated thread

    for(int i=0; i<MAX_UTHREADS; i++){
        if(utTable[i].sleepON == terminatedRunningThread->threadID && utTable[i].state == SLEEPING){
            utTable[i].state = RUNNABLE;
            utTable[i].sleepON = -1;
        }
    }

//     printf(1,"here is i: %d\n", i);

    printf(1,"thread %d done!\n", terminatedRunningThread->threadID);

    terminatedRunningThread->state = UNUSED;
    
    //execute context switch
    sigsend(getpid(), SIGALRM);
    
}


int uthred_self(){
    return currentRunningThread->threadID;
}

int uthred_join(int tid){

    // If that thread has already terminated/not exists, then uthread_join returns immediately.
    if(tid >= MAX_UTHREADS || utTable[tid].state == UNUSED){
        return 0;
    }
    // deadlock
    if(tid == currentRunningThread->threadID){
        return 0;
    }
    
    // The uthread_join function waits for the thread specified by tid to terminate.
    currentRunningThread->state = SLEEPING;
    currentRunningThread->sleepON = tid;
    return 0;
}

int uthred_sleep(int ticks){

// The uthread_sleep function should suspend the execution of the current thread for at least ticks (here
// ticks represent the value of ticks variable defined at trap.c). Namely, uthread_sleep resembles sleep
// system call but is applied to the user threads.
//     int system_ticks = uptime();
//     currentRunningThread->wakeup_time = system_ticks+ticks;
//     currentRunningThread->state = SLEEPING;
//     return 0;
}


void debugStack(int mode)
{
    uint esp = 0;
    asm("movl %%esp, %0;" : "=r" (esp));
        if (mode)
        {
        printf(1,"esp: %d\n",*(int*)(esp));
        printf(1,"esp+4: %d\n",*(int*)(esp+4));
        printf(1,"esp+8: %d\n",*(int*)(esp+8));
        printf(1,"esp+12: %d\n",*(int*)(esp+12));
        printf(1,"esp+16: %d\n",*(int*)(esp+16));
        printf(1,"esp+20: %d\n",*(int*)(esp+20));
        printf(1,"esp+24: %d\n",*(int*)(esp+24));
        printf(1,"esp+28: %d\n",*(int*)(esp+28));
        printf(1,"esp+32: %d\n",*(int*)(esp+32));
        printf(1,"esp+36: %d\n",*(int*)(esp+36));
        printf(1,"esp+40: %d\n",*(int*)(esp+40));
        printf(1,"esp+44: %d\n",*(int*)(esp+44));
        printf(1,"esp+48: %d\n",*(int*)(esp+48));
        }
}




int foo(int a)
{
    return a+1;
}
