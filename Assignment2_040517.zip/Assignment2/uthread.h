
// struct trapframe;

#ifndef uthread_h
#define uthread_h

typedef enum  {RUNNABLE, RUNNING ,SLEEPING ,UNUSED} uthreadState;

typedef struct uthread {
    int threadID;
    uthreadState state; 
    struct trapframe *tf;
    char* stack;
    int sleepON;
    int firstRun;
    int wakeup_time;

}uthread;


int uthread_init();
void uthread_schedule();
int uthread_create(void (*start_func)(void *), void*arg);
void uthread_exit();
int uthred_self();
int uthred_join(int tid);
int uthred_sleep(int ticks);
extern int foo(int);

#endif