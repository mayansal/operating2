
#include "types.h"
#include "stat.h"
#include "user.h"
 
void handler(int num){
    // printf(1, "%d\n", 3);
}

int main() {
    sighandler_t old = (sighandler_t)signal(1, handler);
    printf(1, "old: %d\n", old);
    sighandler_t new = (sighandler_t)signal(1, handler);
    printf(1, "new: %d\n", new);
    int result = sigsend(2, 1);
    printf(1, "result: %d\n", result);
    exit();
}
